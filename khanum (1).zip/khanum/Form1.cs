namespace khanum
{
    public partial class Form1 : Form
    {
        private int maxcount;
        private int count;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user, password;
            user = "maryam khanum";
            password = "22011556-003";
            if ((textBox1.Text == user) && (textBox2.Text == password))
            {
                MessageBox.Show("welcome User");
            }
            else
            {
                count++;
                int remain = maxcount - count;
                MessageBox.Show("Wrong user name or password" + "\t" + remain + "" + "tries left");
                textBox2.Clear();
                textBox1.Clear();
                textBox1.Focus();
                if (count >= maxcount)
                {
                    MessageBox.Show("Max try exceeded.");
                    Application.Exit();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear(); // Clear the username textbox
            textBox2.Clear(); // Clear the password textbox
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
